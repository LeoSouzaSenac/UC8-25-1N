/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aventura.rpg;

/**
 *
 * @author Professor
 */
public class PocaoMana implements Item{
    // cura a mana do personagem
    // n pode curar mais do que a mana maxima
    @Override
    public void efeito (Personagem per) {
        int novaMana = per.mana + 25;
        if (novaMana > per.MANA_MAX) { novaMana = per.MANA_MAX;}
        per.setMana(novaMana);
        
    }
}
