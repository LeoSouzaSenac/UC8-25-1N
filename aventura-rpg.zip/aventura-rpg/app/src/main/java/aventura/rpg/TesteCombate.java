package aventura.rpg;

public class TesteCombate {

    public static void main(String[] args) {
        
        // Criando dois bárbaros
        Barbaro bar1 = new Barbaro("Ragnar", 80, 10, 15, 5);
        Barbaro bar2 = new Barbaro("Bjorn", 75, 10, 14, 6);
        
        System.out.println("=== Início do Combate ===");
        System.out.println(bar1.nome + " vs " + bar2.nome + "\n");
        
        int turno = 1;
        while (bar1.vida > 0 && bar2.vida > 0) {
            System.out.println("Turno " + turno);

            // Bárbaro 1 ataca Bárbaro 2
            if (bar1.mana > 0 && Math.random() < 0.5) { // 50% chance de usar Fúria
                bar1.usarHabilidade(bar2);
            } else {
                bar1.atacar(bar2, 1, 6);
            }

            // Verifica se Bárbaro 2 morreu
            if (bar2.vida <= 0) {
                System.out.println(bar2.nome + " foi derrotado!");
                break;
            }

            // Bárbaro 2 ataca Bárbaro 1
            if (bar2.mana > 0 && Math.random() < 0.5) {
                bar2.usarHabilidade(bar1);
            } else {
                bar2.atacar(bar1, 1, 6);
            }

            // Verifica se Bárbaro 1 morreu
            if (bar1.vida <= 0) {
                System.out.println(bar1.nome + " foi derrotado!");
                break;
            }

            // Exibe status
            System.out.println("Status: " + bar1.nome + " (" + bar1.vida + " HP) | "
                                               + bar2.nome + " (" + bar2.vida + " HP)\n");

            turno++;
        }

        System.out.println("=== Fim do Combate ===");
    }
}
