/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aventura.rpg;

/**
 *
 * @author Professor
 */
public class Ladino extends Personagem{

    private final int BONUS_FORCA = 2;
    private final int VIDA_MIN = 70;
    private final int BARB_MANA_MAX = 25;
    
    public Ladino(String nome, int vida, int mana, int forca, int agilidade) {
        super(nome, vida, mana, forca, agilidade);
        this.forca += BONUS_FORCA;
        if (this.vida < VIDA_MIN) {this.vida = VIDA_MIN;}
        if (this.mana > BARB_MANA_MAX) {this.mana = BARB_MANA_MAX;}
    }

    
    // Bárbaro: força alta, vida alta, mana baixa; habilidade Fúria (ataque extra).
    // RN14: Recebe +2 de força ao ser criado.
    // RN15: Habilidade Fúria aumenta o dano físico em 50% por um turno (custa 1 de mana).
    
    
    @Override
    public void usarHabilidade(Personagem inimigo) {
    if (this.mana > 0) {
        this.mana -= 1;

        int dano = (int) (super.calcularDano(3, 6) * 1.5);
        int chance = calcularChanceDeAcerto(inimigo);

        // limitar chance
        if (chance > 95) chance = 95;
        if (chance < 10) chance = 10;

        int numero = (int) (Math.random() * 100);

        if (numero <= chance) {
            inimigo.recebeDano(dano);
            System.out.println(nome + " usou Fúria e acertou " + inimigo.nome + " causando " + dano + " de dano!");
        } else {
            System.out.println(nome + " usou Fúria e errou o ataque!");
        }
        
    } else {
        System.out.println(nome + " não tem mana suficiente para usar Fúria!");
    }
}
}
