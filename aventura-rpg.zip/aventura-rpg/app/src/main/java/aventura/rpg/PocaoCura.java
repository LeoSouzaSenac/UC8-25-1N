/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aventura.rpg;

/**
 *
 * @author Professor
 */
public class PocaoCura implements Item{
    // cura a vida do personagem
    // n pode curar mais do que a vida maxima
    @Override
    public void efeito (Personagem per) {
        int novaVida = per.vida + 25;
        if (novaVida > per.VIDA_MAX) { novaVida = per.VIDA_MAX;}
        per.setVida(novaVida);
        
    }
}
