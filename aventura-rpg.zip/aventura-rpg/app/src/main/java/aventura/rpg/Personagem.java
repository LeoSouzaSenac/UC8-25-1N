/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aventura.rpg;

/**
 *
 * @author Professor
 */
public abstract class Personagem {

    protected final int VIDA_MAX;
    protected final int MANA_MAX;

    protected String nome;
    protected int vida;
    protected int mana;
    protected int forca;
    protected int agilidade;

    public Personagem(String nome, int vida, int mana, int forca, int agilidade) {

        this.nome = nome;
        this.vida = vida;
        this.mana = mana;

        this.VIDA_MAX = this.vida;
        this.MANA_MAX = this.mana;

        this.forca = forca;
        this.agilidade = agilidade;
    }

    public void atacar(Personagem inimigo, int dados, int lados) {

        int dano = calcularDano(dados,lados);

        int chance = calcularChanceDeAcerto(inimigo);

        // limitar chance
        if (chance > 95) {
            chance = 95;
        }
        if (chance < 10) {
            chance = 10;
        }

        int numero = (int) (Math.random() * 100);

        if (chance >= numero) {
            inimigo.recebeDano(dano);
            System.out.println(nome + " acertou " + inimigo.nome + " causando " + dano + " de dano!");
        } else {
            System.out.println(nome + " errou o ataque!");
        }

    }

    public abstract void usarHabilidade(Personagem inimigo);

    public void usarItem(Item item) {
        item.efeito(this);
    }

    public boolean fugir() {
        return true;
    }

    public int rolarDados(int quantidade, int lados) {
        return Dados.rolarDados(quantidade, lados);
    }

    public int calcularDano(int dados, int lados) {
        return this.forca + this.rolarDados(dados, lados);
    }

    public int calcularChanceDeAcerto(Personagem inimigo) {
        return 50 + (this.agilidade - inimigo.agilidade) * 5;
    }

    public void recebeDano(int dano) {
        this.vida -= dano;
        if (this.vida < 0) {
            this.vida = 0;
        }
    }
    
    public void setVida(int novaVida){
        this.vida = novaVida;
    }
    
    public void setMana(int novaMana){
        this.mana = novaMana;
    }

}
