/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aventura.rpg;

/**
 *
 * @author Professor
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;

public class FadeUtil {

    private JLabel label;
    private Image currentImage;
    private Image nextImage;
    private float alpha = 0f;
    private Timer fadeTimer;

    // Mantém tamanho e posição fixos durante o fade
    private int currentX, currentY, currentW, currentH;
    private int nextX, nextY, nextW, nextH;

    public FadeUtil(JLabel label, String initialImagePath) {
        this.label = label;
        this.currentImage = new ImageIcon(getClass().getResource(initialImagePath)).getImage();
        label.setIcon(new ImageIcon(currentImage));
    }

    public void fadeTo(String imagePath) {
        nextImage = new ImageIcon(getClass().getResource(imagePath)).getImage();
        alpha = 0f;

        int labelWidth = label.getWidth();
        int labelHeight = label.getHeight();

        // Calcular proporção da imagem atual
        double ratioCurrent = (double) currentImage.getWidth(null) / currentImage.getHeight(null);
        currentW = labelWidth;
        currentH = (int) (labelWidth / ratioCurrent);
        if (currentH > labelHeight) {
            currentH = labelHeight;
            currentW = (int) (labelHeight * ratioCurrent);
        }
        currentX = (labelWidth - currentW) / 2;
        currentY = (labelHeight - currentH) / 2;

        // Calcular proporção da próxima imagem
        double ratioNext = (double) nextImage.getWidth(null) / nextImage.getHeight(null);
        nextW = labelWidth;
        nextH = (int) (labelWidth / ratioNext);
        if (nextH > labelHeight) {
            nextH = labelHeight;
            nextW = (int) (labelHeight * ratioNext);
        }
        nextX = (labelWidth - nextW) / 2;
        nextY = (labelHeight - nextH) / 2;

        if (fadeTimer != null && fadeTimer.isRunning()) fadeTimer.stop();

        fadeTimer = new Timer(50, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                alpha += 0.05f;
                if (alpha >= 1f) {
                    alpha = 1f;
                    currentImage = nextImage;
                    nextImage = null;
                    fadeTimer.stop();
                }
                repaintLabel();
            }
        });
        fadeTimer.start();
    }

    private void repaintLabel() {
        if (nextImage != null) {
            int labelWidth = label.getWidth();
            int labelHeight = label.getHeight();

            BufferedImage combined = new BufferedImage(labelWidth, labelHeight, BufferedImage.TYPE_INT_ARGB);
            Graphics2D g = combined.createGraphics();

            // Desenhar imagem atual
            g.drawImage(currentImage, currentX, currentY, currentW, currentH, null);

            // Desenhar próxima imagem com alpha
            g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, alpha));
            g.drawImage(nextImage, nextX, nextY, nextW, nextH, null);

            g.dispose();
            label.setIcon(new ImageIcon(combined));
        } else {
            label.setIcon(new ImageIcon(currentImage));
        }
    }
}
